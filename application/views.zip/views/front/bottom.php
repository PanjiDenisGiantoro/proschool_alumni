 <!-- Control Sidebar -->
 <aside class="control-sidebar control-sidebar-dark">
   <!-- Control sidebar content goes here -->
   <div class="p-3">
     <h5>Title</h5>
     <p>Sidebar content</p>
   </div>
 </aside>
 <!-- /.control-sidebar -->

 <!-- Main Footer -->
 <footer class="main-footer">
    <font color="black">Copyright &copy; 2022 <a href="https://www.proschool.id" target="_blank"><font color="black">ProSchool</a></font>.
    Tim ICT Desatech Nusantara.</font>
    <div class="float-right d-none d-sm-inline-block">
      <font color="black">Version 2.0</font>
    </div>
  </footer>
 <!-- <footer class="main-footer">
   
   <div class="float-right d-none d-sm-inline">
     All rights reserved.
   </div>

   <?php echo "Copyright © " . "2014 -" . (int) date('Y'); ?> ALUMNI | <?php echo $nama_sekolah; ?>
 </footer>
 </div> -->
 <!-- ./wrapper -->
 <!-- WA SCRIPTS -->
 <!-- Live Chat Widget powered by https://keyreply.com/chat/ -->
 <!-- Advanced options: -->
 <!-- data-align="left" -->
 <!-- data-overlay="true" -->
 <script data-align="right" data-overlay="false" id="keyreply-script" src="//keyreply.com/chat/widget.js" data-color="#E4392B" data-apps="JTdCJTIyd2hhdHNhcHAlMjI6JTIyNjI4NTIyODI5Njc3NiUyMiU3RA=="></script>
 <!-- jQuery -->
 <script src="<?php echo base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
 <!-- Bootstrap 4 -->
 <script src="<?php echo base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
 <!-- AdminLTE App -->
 <script src="<?php echo base_url(); ?>assets/dist/js/adminlte.min.js"></script>


 </body>

 </html>